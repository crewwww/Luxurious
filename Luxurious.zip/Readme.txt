1.Install software

2.Send me your HW ID number and Your username

3 Your license code will be send to you

4.Because an aplication connects to blockchain,please switch off your firewall to get better results

5.Injoy

Contacts:

support@luxuriousoftware.com

sales@luxuriousofware.com

Telegram channel:

http://t.me/joinchat/AAAAAELCJrCxt-HMqcpJOA



